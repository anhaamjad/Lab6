class Graph:
    def __init__(self):
        self.adj = {}                      
    def add_edge(self, v, w):
        if v not in self.adj:
            self.adj[v] = []
        if w not in self.adj:
            self.adj[w] = []
        self.adj[v].append(w)
    def dfs_util(self, v, visited):
        visited[v] = True
        print(v, end=" ")
        for i in self.adj[v]:
            if not visited[i]:
                self.dfs_util(i, visited)
    def dfs(self, v):
        visited = {}
        for node in self.adj:
            visited[node] = False
        self.dfs_util(v, visited)
g = Graph()
g.add_edge(0, 1)
g.add_edge(0, 2)
g.add_edge(1, 2)
g.add_edge(2, 0)
g.add_edge(2, 3)
g.add_edge(3, 3)
g.dfs(2)
print()