class Graph:
    def __init__(self):
        self.adj = {}
    def add_edge(self, v, w):
        if v not in self.adj:
            self.adj[v] = []
        if w not in self.adj:
            self.adj[w] = []
        self.adj[v].append(w)
    def dfs_stack(self, start, goal):
        stack = [[start]]                  
        visited = []
        while len(stack) > 0:
            path = stack.pop()
            node = path[-1]
            if node in visited:
                continue
            visited.append(node)
            print("Visiting:", node)
            if node == goal:
                print("Goal found!")
                return path
            for nb in reversed(self.adj[node]):
                if nb not in visited:
                    stack.append(path + [nb])
        return None
g = Graph()
g.add_edge("A", "B")
g.add_edge("A", "F")
g.add_edge("A", "D")
g.add_edge("A", "E")
g.add_edge("B", "K")
g.add_edge("B", "J")
g.add_edge("K", "N")
g.add_edge("K", "M")
g.add_edge("D", "G")
g.add_edge("E", "C")
g.add_edge("E", "H")
g.add_edge("E", "I")
g.add_edge("I", "L")
path = g.dfs_stack("A", "Z" )
if path is None:
    print("goal not found")
else:
    print("Path:","->".join(path))