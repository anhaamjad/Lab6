class Graph:
    def __init__(self):
        self.adj = {}
    def add_edge(self, v, w):
        if v not in self.adj:
            self.adj[v] = []
        if w not in self.adj:
            self.adj[w] = []
        self.adj[v].append(w)
    def dfs_stack(self, start):
        stack = [start]
        visited = []
        while len(stack) > 0:
            node = stack.pop()
            if node not in visited:
                visited.append(node)
                for nb in reversed(self.adj[node]):
                    if nb not in visited:
                        stack.append(nb)
        return visited
g = Graph()
g.add_edge(1, 2)
g.add_edge(1, 7)
g.add_edge(1, 8)
g.add_edge(2, 3)
g.add_edge(2, 6)
g.add_edge(3, 4)
g.add_edge(3, 5)
g.add_edge(8, 9)
g.add_edge(8, 12)
g.add_edge(9, 10)
g.add_edge(9, 11)
print("DFS from 1:", g.dfs_stack(1))